/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";
import wSaleUtils from "@website_sale/js/website_sale_utils";
import ProductWishlist from '@website_sale_wishlist/js/website_sale_wishlist'; // Adjust the path to your actual module
import { jsonrpc } from '@web/core/network/rpc_service';

publicWidget.registry.ProductWishlist.include({
    /**
     * @override
     * Add custom logic to check forecasted quantity before adding to cart.
     */
  _addToCart: function (productID, qty) {
        const self = this;
        const $tr = this.$(`tr[data-product-id="${productID}"]`);
        const productTrackingInfo = $tr.data('product-tracking-info');

        if (productTrackingInfo) {
            productTrackingInfo.quantity = qty;
            $tr.trigger('add_to_cart_event', [productTrackingInfo]);
        }

        // Fetch the forecast quantity from the server
        return jsonrpc("/shop/cart/update_json", 'call', {
            product_id: productID,
            add_qty: qty,
        }).then(function (data) {
            if (data<0) {
                // Show alert and do not proceed with cart update
                alert(data.warning);
                return;
            }

            // Proceed with the original cart update logic if forecast quantity is valid
            wSaleUtils.updateCartNavBar(data);
            wSaleUtils.showCartNotification(self, data.notification_info);
        }).catch(function (e) {
            if (!(e instanceof RPCError)) {
                return Promise.reject(e);
            }
        });
    },
});

from odoo import http
from odoo.http import request
from odoo.addons.website_sale.controllers.main import WebsiteSale

class WebsiteSale(WebsiteSale):

    @http.route('/shop/cart/update_json', type='json', auth="public", website=True)
    def cart_update_json(self, **post):
        product_id = int(post.get('product_id', 0))
        if product_id:
            product = request.env['product.product'].sudo().browse(product_id)
            if product.virtual_available < 0:
                return product.virtual_available

        return super(WebsiteSale, self).cart_update_json(**post)
